package com.ssafy.product;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.util.DBUtil;


@WebServlet("/registerproduct")
public class ProductRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private DBUtil util = DBUtil.getInstance();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("productname");
		String price = request.getParameter("productprice");
		String desc = request.getParameter("productdesc");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		int cnt = 0;
		try {
			conn = util.getConnection();
			String sql = "insert into product (product_name, product_price, product_desc, regtime) \n";
			sql += "values (?, ?, ?, now())";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, price);
			pstmt.setString(3, desc);
			
			cnt = pstmt.executeUpdate();	// 몇 개가 udpate 됐는지
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.close(pstmt, conn);
		}
		
		// 응답 페이지 만들기
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("    <meta charset=\"UTF-8\">");
		out.println("    <title>상품 등록 완료</title>");
		out.println("    <meta name=\"viewport\" productdesc=\"width=device-width, initial-scale=1\">");
		out.println("    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">");
		out.println("    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>");
		out.println("    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>");
		out.println("    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script>");
		out.println("    <script type=\"text/javascript\">");
		out.println("        $(document).ready(function () {");
		out.println("            $(\"#mvListBtn\").click(function () {");
		out.println("                location.href = \"/hwbackend01_서울_07반_김사라/productview\";");
		out.println("            });");
		out.println("            $(\"#mvRegisterBtn\").click(function () {");
		out.println("                location.href = \"/index.jsp\";");
		out.println("            });");
		out.println("        });");
		out.println("    </script>");
		out.println("</head>");
		out.println("<body>");
		out.println("    <div class=\"container text-center mt-3\">");
		out.println("        <div class=\"col-lg-8 mx-auto\">");
		if (cnt != 0) {
		out.println("            <div class=\"jumbotron\">");
		out.println("                <h1 class=\"text-primary\">상품 등록 성공 ^^</h1>");
		out.println("                <p class=\"mt-4\"><button type=\"button\" id=\"mvListBtn\" class=\"btn btn-outline-dark\">등록한 상품 보기</button>");
		out.println("                </p>");
		out.println("            </div>");
		}
		else {
		out.println("            <div class=\"jumbotron\">");
		out.println("                <h1 class=\"text-danger\">상품 등록 실패 T.T</h1>");
		out.println("                <p class=\"mt-4\"><button type=\"button\" id=\"mvRegisterBtn\" class=\"btn btn-outline-dark\">글쓰기 페이지로 이동</button>");
		out.println("                </p>");
		out.println("            </div>");
		out.println("        </div>");
		out.println("    </div>");
		}
		out.println("</body>");
		out.println("</html>");
	}
}
