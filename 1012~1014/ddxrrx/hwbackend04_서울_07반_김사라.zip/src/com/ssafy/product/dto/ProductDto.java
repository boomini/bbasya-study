package com.ssafy.product.dto;

public class ProductDto {
	
	private int productNo;
	private String userid;
	private String product_name;
	private int product_price;
	private String product_desc;
	private String regTime;
	
	public int getProductNo() {
		return productNo;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}
	public String getName() {
		return product_name;
	}
	public void setName(String name) {
		this.product_name = name;
	}
	public int getPrice() {
		return product_price;
	}
	public void setPrice(int price) {
		this.product_price = price;
	}
	public String getDesc() {
		return product_desc;
	}
	public void setDesc(String desc) {
		this.product_desc = desc;
	}
	public String getRegTime() {
		return regTime;
	}
	public void setRegTime(String regTime) {
		this.regTime = regTime;
	}
	
}
