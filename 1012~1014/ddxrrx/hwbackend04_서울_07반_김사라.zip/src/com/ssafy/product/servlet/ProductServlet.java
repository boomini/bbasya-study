package com.ssafy.product.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.product.dto.ProductDto;
import com.ssafy.product.dto.MemberDto;
import com.ssafy.util.DBUtil;

@WebServlet("/product")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private DBUtil dbUtil = DBUtil.getInstance();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String act = request.getParameter("act");
		String path = "/index.jsp";
		if ("register".equals(act)) { // 상품 등록하기
			path = registreProduct(request, response);
		} else if ("list".equals(act)) { // 상품 목록
			path = listProduct(request, response);
		} else if ("delete".equals(act)) {
			path = deleteProduct(request, response);
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);

	}

	private String deleteProduct(HttpServletRequest request, HttpServletResponse response) {
		int productNo = Integer.parseInt(request.getParameter("productNo"));
		HttpSession session = request.getSession();
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		if(memberDto != null) {
			try {
				conn = dbUtil.getConnection();
				StringBuilder deleteProduct = new StringBuilder();
				deleteProduct.append("delete from product \n");
				deleteProduct.append("where productNo = ?");
				pstmt = conn.prepareStatement(deleteProduct.toString());
				pstmt.setInt(1, productNo);
				pstmt.executeUpdate();
				return "/product?act=list";
			} catch (Exception e) {
				e.printStackTrace();
				return "/error/error.jsp";
			} finally {
				dbUtil.close(pstmt, conn);
			}
		} else
			return "/user/login.jsp";
	}

	private String lastCookie(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

	private String registreProduct(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");
		if (memberDto != null) {	// 로그인 성공
			String name = request.getParameter("name");
			String price = request.getParameter("price");
			String desc = request.getParameter("desc");
			
//			Cookie 저장			
//			Cookie cookie = new Cookie("user_id", memberDto.getUserId()+"&"+name+"&"+price+"&"+desc);
//			
//			cookie.setMaxAge(60*60*24*365*40);
//			cookie.setPath(request.getContextPath());		
//			response.addCookie(cookie);
			
//			DB에 등록할 상품 정보 저장
			Connection conn = null;
			PreparedStatement pstmt = null;
			int cnt = 0;
			try {
				conn = dbUtil.getConnection();
				StringBuilder registerProduct = new StringBuilder();
				registerProduct
						.append("insert into product (userid, product_name, product_price, product_desc, regtime) \n");
				registerProduct.append("values (?,?,?,?, now())");
				pstmt = conn.prepareStatement(registerProduct.toString());
				pstmt.setString(1, memberDto.getUserId());
				pstmt.setString(2, name);
				pstmt.setString(3, price);
				pstmt.setString(4, desc);
				cnt = pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				dbUtil.close(pstmt, conn);
			}
			return cnt != 0 ? "/product/writesuccess.jsp" : "/product/writefail.jsp";
		} else {
			return "/user/login.jsp";
		}
	}

	private String listProduct(HttpServletRequest request, HttpServletResponse response) {
		String key = request.getParameter("key"); // 상품명 or 가격
		String word = request.getParameter("word"); // 검색어
		
		HttpSession session = request.getSession();
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");
		if (memberDto != null) {
			List<ProductDto> list = new ArrayList<ProductDto>();
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = dbUtil.getConnection();
				StringBuilder listProduct = new StringBuilder();
				listProduct.append("select productNo, userid, product_name, product_price, product_desc, regtime \n");
				listProduct.append("from product \n");
				if(word!=null) {
					if(key.equals("name"))
						listProduct.append("where product_name like ? \n");
					else if(key.equals("price"))
						listProduct.append("where product_price <= ? \n");
				}
				listProduct.append("order by productNo desc \n");
				pstmt = conn.prepareStatement(listProduct.toString());
				if(word!=null) {
					if(key.equals("name"))
						pstmt.setString(1, "%" + word + "%");
					else if(key.equals("price")) {
						int word2 = Integer.parseInt(word);
						pstmt.setInt(1, word2);
					}
				}
				rs = pstmt.executeQuery();
				while (rs.next()) {
					ProductDto productDto = new ProductDto();
					productDto.setProductNo(rs.getInt("productNo"));
					productDto.setUserid(rs.getString("userid"));
					productDto.setName(rs.getString("product_name"));
					productDto.setPrice(rs.getInt("product_price"));
					productDto.setDesc(rs.getString("product_desc"));
					productDto.setRegTime(rs.getString("regtime"));

					list.add(productDto);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				dbUtil.close(rs, pstmt, conn);
			}

			request.setAttribute("products", list);

			return "/product/list.jsp";
		} else {
			return "/user/login.jsp";
		}
	}
}
