package com.ssafy.product.dto;

public class ProductDto {
	
	private int productNo;
	private String product_name;
	private String product_price;
	private String product_desc;
	private String regTime;
	
	public int getProductNo() {
		return productNo;
	}
	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}
	public String getName() {
		return product_name;
	}
	public void setName(String name) {
		this.product_name = name;
	}
	public String getPrice() {
		return product_price;
	}
	public void setPrice(String price) {
		this.product_price = price;
	}
	public String getDesc() {
		return product_desc;
	}
	public void setDesc(String desc) {
		this.product_desc = desc;
	}
	public String getRegTime() {
		return regTime;
	}
	public void setRegTime(String regTime) {
		this.regTime = regTime;
	}
	
}
