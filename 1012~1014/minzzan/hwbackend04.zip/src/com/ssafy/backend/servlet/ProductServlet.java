package com.ssafy.backend.servlet;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.ssafy.backend.dto.Product;
import com.ssafy.backend.dto.User;
import com.ssafy.util.DBUtil;

@WebServlet("/product")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private DBUtil dbUtil = DBUtil.getInstance();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String act = request.getParameter("act");
		String path = "/index.jsp";
		if ("register".equals(act)) {
			path = registerProduct(request, response);
//			listProduct(request, response);
		} else if ("list".equals(act)) {
			path = listProduct(request, response);
		} else if ("last".equals(act)) {
			path = lastProduct(request, response);
		} else if ("search".equals(act)) {
			path = searchProduct(request, response);
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}

	private String searchProduct(HttpServletRequest request, HttpServletResponse response) {
		String key = request.getParameter("key"); // 아이디, 제목, 내용
		String word = request.getParameter("word"); // 검색어

		key = key == null ? "" : key.trim();
		word = word == null ? "" : word.trim();

		List<Product> list = new ArrayList<Product>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dbUtil.getConnection();
			StringBuilder listProduct = new StringBuilder();
			listProduct.append("select p.pnum, p.pname, p.price, p.des, p.regtime, m.username \n");
			listProduct.append("from product p, ssafy_member m \n");
			listProduct.append("where p.userid = m.userid \n");
			if (!word.isEmpty()) {
				if (key.equals("pname"))
					listProduct.append("and p.pname = ? \n");
				else if (key.equals("price"))
					listProduct.append("and p.price <= ? \n");
			}
			listProduct.append("order by p.regtime desc \n");
			pstmt = conn.prepareStatement(listProduct.toString());
			if (!word.isEmpty()) {
				if (key.equals("pname"))
					pstmt.setString(1, word);
				else if (key.equals("price"))
					pstmt.setInt(1, Integer.parseInt(word));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setPnum(rs.getString("pnum"));
				product.setPname(rs.getString("pname"));
				product.setPrice(rs.getInt("price"));
				product.setDes(rs.getString("des"));
				product.setRegtime(rs.getString("regtime"));

				list.add(product);
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글목록 출력 중 문제 발생!!!");
			return "/error/error.jsp";
		} finally {
			dbUtil.close(rs, pstmt, conn);
		}
		request.setAttribute("products", list);

		return "/list.jsp";
	}

	private String lastProduct(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("userinfo");
		if (user != null) {
			Cookie[] cookies = request.getCookies();
			String pnum = "";
			if (cookies != null) {
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals(user.getId())) {
						pnum = cookie.getValue(); // 저장 상품 번호
						break;
					}
				}
			}

			Product product = null;
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			System.out.println("여기는 오니?");
			try {
				conn = dbUtil.getConnection();
				StringBuilder listProduct = new StringBuilder();
				listProduct.append("select pnum, pname, price, des \n");
				listProduct.append("from product \n");
				listProduct.append("where pnum = ? \n");

				pstmt = conn.prepareStatement(listProduct.toString());
				pstmt.setString(1, pnum);

				rs = pstmt.executeQuery();
				if (rs.next()) {
					product = new Product();
					product.setPnum(rs.getString("pnum"));
					product.setPname(rs.getString("pname"));
					product.setPrice(Integer.parseInt(rs.getString("price")));
					product.setDes(rs.getString("des"));

					System.out.println(product.getPname());
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				dbUtil.close(rs, pstmt, conn);
			}

			request.setAttribute("lastproduct", product);

			return "/regist_result.jsp";
		} else
			return "/index.jsp";
	}

	private String registerProduct(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("userinfo");
		if (user != null) {
			String userid = user.getId();
			String pnum = request.getParameter("pnum");
			String pname = request.getParameter("pname");
			int price = Integer.parseInt(request.getParameter("price"));
			String des = request.getParameter("des");

			Connection conn = null;
			PreparedStatement pstmt = null;
			int cnt = 0;
			try {
				conn = dbUtil.getConnection();
				StringBuilder registerProduct = new StringBuilder();
				registerProduct.append("insert into product (userid, pnum, pname, price,des,regtime) \n");
				registerProduct.append("values (?, ?, ?, ?,?,now())");
				pstmt = conn.prepareStatement(registerProduct.toString());
				pstmt.setString(1, userid);
				pstmt.setString(2, pnum);
				pstmt.setString(3, pname);
				pstmt.setInt(4, price);
				pstmt.setString(5, des);
				cnt = pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				dbUtil.close(pstmt, conn);
			}

//			cookie 설정
			Cookie cookie = new Cookie(userid, pnum);
			cookie.setPath(request.getContextPath());
			cookie.setMaxAge(60 * 60 * 24 * 365 * 40);// 40년간 저장.
			response.addCookie(cookie);

			return cnt != 0 ? "/index.jsp" : "/index.jsp";
		} else // 로그인을 안했을때 책등록 안됨을 어떻게 표시해야,,?
			return "/index.jsp";
	}

	private String listProduct(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		User User = (User) session.getAttribute("userinfo");
		if (User != null) {
			List<Product> list = new ArrayList<Product>();
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = dbUtil.getConnection();
				StringBuilder listProduct = new StringBuilder();
				listProduct.append("select p.pnum, p.pname, p.price, p.des, p.regtime, m.username \n");
				listProduct.append("from product p, ssafy_member m \n");
				listProduct.append("where p.userid = m.userid \n");
				listProduct.append("order by p.regtime desc \n");
				pstmt = conn.prepareStatement(listProduct.toString());
				rs = pstmt.executeQuery();
				while (rs.next()) {
					Product product = new Product();
					product.setPnum(rs.getString("pnum"));
					product.setPname(rs.getString("pname"));
					product.setPrice(Integer.parseInt(rs.getString("price")));
					product.setDes(rs.getString("des"));
					product.setRegtime(rs.getString("regtime"));

					list.add(product);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				dbUtil.close(rs, pstmt, conn);
			}

			request.setAttribute("products", list);

			return "/list.jsp";
		} else
			return "/index.jsp";
	}

}
