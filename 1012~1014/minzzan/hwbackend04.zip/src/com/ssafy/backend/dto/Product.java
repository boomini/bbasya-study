package com.ssafy.backend.dto;

public class Product {
	private String pnum;
	private String pname;
	private int price;
	private String des;
	private String regtime;

	public Product() {
		super();
	}

	
	public Product(String pname, int price, String des) {
		super();
		this.pname = pname;
		this.price = price;
		this.des = des;
	}

	public String getPnum() {
		return pnum;
	}


	public void setPnum(String pnum) {
		this.pnum = pnum;
	}


	public String getPname() {
		return pname;
	}


	public void setPname(String pname) {
		this.pname = pname;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public String getDes() {
		return des;
	}


	public void setDes(String des) {
		this.des = des;
	}

	public String getRegtime() {
		return regtime;
	}


	public void setRegtime(String regtime) {
		this.regtime = regtime;
	}


	@Override
	public String toString() {
		return "상품명 : "+ pname;
	}

	

}
