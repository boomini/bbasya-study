package com.ssafy.backend.servlet;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.ssafy.backend.dto.Book;
import com.ssafy.backend.dto.User;
import com.ssafy.util.DBUtil;

@WebServlet("/book")
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private DBUtil dbUtil = DBUtil.getInstance();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String act = request.getParameter("act");
		String path = "/index.jsp";
		if ("register".equals(act)) {
			registerBook(request, response);
			path = "/regist_result.jsp";
			RequestDispatcher dispatcher = request.getRequestDispatcher(path);
			dispatcher.forward(request, response);
		} else if ("list".equals(act)) {
			path = listBook(request, response);
		}

//		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
//		dispatcher.forward(request, response);
	}

	private String registerBook(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("userinfo");
		if (user != null) {
			String userid = user.getId();
			String isbn = request.getParameter("isbn");
			String title = request.getParameter("title");
			String author = request.getParameter("author");
			int price = Integer.parseInt(request.getParameter("price"));
			String des = request.getParameter("des");

			Connection conn = null;
			PreparedStatement pstmt = null;
			int cnt = 0;
			try {
				conn = dbUtil.getConnection();
				StringBuilder registerBook = new StringBuilder();
				registerBook.append("insert into guestbook (userid, isbn, title, author,price,des,regtime) \n");
				registerBook.append("values (?, ?, ?, ?,?,?,now())");
				pstmt = conn.prepareStatement(registerBook.toString());
				pstmt.setString(1, userid);
				pstmt.setString(2, isbn);
				pstmt.setString(3, title);
				pstmt.setString(4, author);
				pstmt.setInt(5, price);
				pstmt.setString(6, des);
				cnt = pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				dbUtil.close(pstmt, conn);
			}
			
			return cnt != 0 ? "/regist_result.jsp" : "/index.jsp";
		} else // 로그인을 안했을때 책등록 안됨을 어떻게 표시해야,,?
			return "/index.jsp";
	}

	private String listBook(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		User User = (User) session.getAttribute("userinfo");
		if (User != null) {
			List<Book> list = new ArrayList<Book>();
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = dbUtil.getConnection();
				StringBuilder listBook = new StringBuilder();
				listBook.append("select g.isbn, g.title, g.author, g.price, g.des, g.regtime, m.username \n");
				listBook.append("from guestbook g, ssafy_member m \n");
				listBook.append("where g.userid = m.userid \n");
				listBook.append("order by g.regtime desc \n");
				pstmt = conn.prepareStatement(listBook.toString());
				rs = pstmt.executeQuery();
				while (rs.next()) {
					Book book = new Book();
					book.setIsbn(rs.getString("isbn"));
					book.setTitle(rs.getString("title"));
					book.setAuthor(rs.getString("author"));
					book.setPrice(Integer.parseInt(rs.getString("price")));
					book.setDesc(rs.getString("des"));
					book.setRegtime(rs.getString("regtime"));

					list.add(book);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				dbUtil.close(rs, pstmt, conn);
			}

			request.setAttribute("books", list);

			return "/regist_result.jsp";
		} else
			return "/index.jsp";
	}

}
